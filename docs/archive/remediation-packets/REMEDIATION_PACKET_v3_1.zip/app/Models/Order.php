<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Order extends Model
{
    public const STATUS_FLOW = [
        'pending' => ['paid', 'cancelled'],
        'paid' => ['processing', 'cancelled'],
        'processing' => ['shipped', 'cancelled'],
        'shipped' => ['completed'],
        'completed' => [],
        'cancelled' => [],
    ];

    /**
     * Transisi yang boleh dipilih operator. Status `paid` tidak termasuk:
     * belum ada kontrak bukti pembayaran tepercaya yang dapat diverifikasi.
     */
    public const MANUAL_BLOCKED = ['paid'];

    protected $fillable = [
        'user_id', 'status', 'subtotal', 'discount', 'shipping_fee', 'total',
        'idempotency_key', 'payload_hash', 'shipping_address', 'voucher_id',
    ];

    protected function casts(): array
    {
        return [
            'shipping_address' => 'array',
            'subtotal' => 'integer',
            'discount' => 'integer',
            'shipping_fee' => 'integer',
            'total' => 'integer',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function voucher(): BelongsTo
    {
        return $this->belongsTo(Voucher::class);
    }

    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    public function canTransitionTo(string $status): bool
    {
        return in_array($status, self::STATUS_FLOW[$this->status] ?? [], true);
    }

    public function isCancellable(): bool
    {
        return $this->canTransitionTo('cancelled') || $this->status === 'cancelled';
    }
}
