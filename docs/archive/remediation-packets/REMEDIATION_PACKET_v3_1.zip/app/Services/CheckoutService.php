<?php

namespace App\Services;

use App\Models\Address;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use App\Models\Voucher;
use Illuminate\Database\DeadlockException;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class CheckoutService
{
    public const MAX_QUANTITY = 99;

    private const MAX_LOCK_RETRIES = 3;

    private const LOCK_RETRY_BASE_MICROSECONDS = 25_000;

    /** Keranjang server di sesi (bertahan saat login); hanya menyimpan product_id => quantity. */
    public static function cartKey(Request $request): string
    {
        return 'cart';
    }

    public static function cart(Request $request): array
    {
        return $request->session()->get(self::cartKey($request), []);
    }

    private static function validateCart(array $cart): void
    {
        foreach ($cart as $productId => $quantity) {
            if (! ctype_digit((string) $productId) || is_bool($quantity)
                || filter_var($quantity, FILTER_VALIDATE_INT, FILTER_NULL_ON_FAILURE) === null
                || (int) $quantity < 1 || (int) $quantity > self::MAX_QUANTITY) {
                throw ValidationException::withMessages(['cart' => 'Isi keranjang tidak valid.']);
            }
        }
    }

    /** Harga selalu diambil ulang dari database, bukan dari klien atau sesi. */
    public static function priced(array $cart): array
    {
        self::validateCart($cart);

        $products = Product::whereIn('product_id', array_keys($cart))->get()->keyBy('product_id');
        $lines = [];
        foreach ($cart as $productId => $quantity) {
            $product = $products->get($productId);
            if (! $product) {
                continue;
            }
            $unit = self::idr($product->product_price);
            $lines[] = [
                'product_id' => (int) $productId,
                'product_title' => $product->product_title,
                'unit_price' => $unit,
                'quantity' => (int) $quantity,
                'subtotal' => $unit * (int) $quantity,
                'available' => (bool) $product->is_active && (int) $product->stock >= (int) $quantity,
            ];
        }

        return ['items' => $lines, 'subtotal' => array_sum(array_column($lines, 'subtotal'))];
    }

    public static function idr(mixed $price): int
    {
        if (! preg_match('/^([0-9]{1,12})(?:\.0+)?$/', (string) $price, $matches)) {
            throw ValidationException::withMessages(['cart' => 'Harga produk harus berupa rupiah bulat yang valid.']);
        }

        return (int) $matches[1];
    }

    public function checkout(User $user, Address $address, array $cart, string $key, ?string $voucherCode): array
    {
        self::validateCart($cart);
        $voucherCode = $voucherCode ? mb_strtoupper(trim($voucherCode)) : null;

        $existing = Order::where('user_id', $user->id)->where('idempotency_key', $key)->first();
        if ($existing) {
            return [$this->replay($existing, $address, $cart, $voucherCode), false];
        }

        if ($cart === []) {
            throw ValidationException::withMessages(['cart' => 'Keranjang belanja masih kosong.']);
        }

        $hash = $this->hash($address->id, $voucherCode, $cart);

        for ($attempt = 0; $attempt <= self::MAX_LOCK_RETRIES; $attempt++) {
            try {
                $order = DB::transaction(fn () => $this->place($user, $address, $cart, $key, $hash, $voucherCode));

                return [$order, $order->wasRecentlyCreated];
            } catch (QueryException|DeadlockException $e) {
                // Laravel membungkus kegagalan kunci di dalam transaksi bersarang sebagai DeadlockException.
                $transient = $this->isTransientLock($e);
                if (! $transient && ! $this->isUniqueViolation($e)) {
                    throw $e;
                }

                $existing = Order::where('user_id', $user->id)->where('idempotency_key', $key)->first();
                if ($existing) {
                    return [$this->replay($existing, $address, $cart, $voucherCode), false];
                }
                if (! $transient) {
                    throw $e;
                }
                if ($attempt === self::MAX_LOCK_RETRIES) {
                    // Status pulih: kunci idempotensi tetap bisa dipakai ulang oleh klien.
                    abort(503, 'Layanan checkout sedang sibuk, coba lagi sesaat dengan kunci yang sama.');
                }
                usleep(self::LOCK_RETRY_BASE_MICROSECONDS * (2 ** $attempt) + random_int(0, 5_000));
            }
        }

        throw new \LogicException('Checkout retry loop exhausted unexpectedly.');
    }

    private function errorInfo(\Throwable $e): array
    {
        if ($e instanceof QueryException) {
            return (array) ($e->errorInfo ?? []);
        }
        $previous = $e->getPrevious();

        return $previous instanceof QueryException ? (array) ($previous->errorInfo ?? []) : [];
    }

    /** SQLite DEFERRED gagal saat transaksi baca dinaikkan menjadi penulis: BUSY (5) atau LOCKED (6). */
    private function isTransientLock(\Throwable $e): bool
    {
        return DB::getDriverName() === 'sqlite'
            && in_array((int) ($this->errorInfo($e)[1] ?? 0), [5, 6], true);
    }

    private function isUniqueViolation(\Throwable $e): bool
    {
        $info = $this->errorInfo($e);
        $expected = DB::getDriverName() === 'sqlite' ? 19 : 1062;

        return (int) ($info[1] ?? 0) === $expected;
    }

    private function replay(Order $order, Address $address, array $cart, ?string $voucherCode): Order
    {
        // Keranjang dikosongkan setelah commit; retry jaringan membawa keranjang kosong.
        $items = $cart !== [] ? $cart : $order->items->pluck('quantity', 'product_id')->all();
        if (! hash_equals($order->payload_hash, $this->hash($address->id, $voucherCode, $items))) {
            abort(409, 'Kunci idempotensi sudah dipakai untuk pesanan berbeda.');
        }

        return $order->load('items');
    }

    private function hash(int $addressId, ?string $voucherCode, array $cart): string
    {
        $items = array_map('intval', $cart);
        ksort($items);

        return hash('sha256', json_encode([$addressId, $voucherCode, $items]));
    }

    private function place(User $user, Address $address, array $cart, string $key, string $hash, ?string $voucherCode): Order
    {
        // Serialisasi checkout per pengguna untuk batas voucher per pengguna.
        User::whereKey($user->id)->lockForUpdate()->first();

        // Recheck di dalam lock: worker kedua yang lolos lookup awal harus replay sebelum mutasi stok/voucher.
        $existing = Order::where('user_id', $user->id)->where('idempotency_key', $key)->lockForUpdate()->first();
        if ($existing) {
            return $this->replay($existing, $address, $cart, $voucherCode);
        }

        $priced = self::priced($cart);
        if (count($priced['items']) !== count($cart)) {
            throw ValidationException::withMessages(['cart' => 'Ada produk yang tidak lagi tersedia.']);
        }

        foreach ($priced['items'] as $line) {
            $updated = Product::whereKey($line['product_id'])
                ->where('is_active', true)
                ->where('stock', '>=', $line['quantity'])
                ->decrement('stock', $line['quantity']);
            if ($updated !== 1) {
                throw ValidationException::withMessages(['cart' => "Stok {$line['product_title']} tidak mencukupi."]);
            }
        }

        $voucher = $voucherCode ? $this->claimVoucher($user, $voucherCode) : null;
        $discount = $voucher ? min($voucher->discount_amount, $priced['subtotal']) : 0;
        // shortcut: ongkir 0 sampai tarif pengiriman ditentukan.
        $shipping = 0;

        $order = Order::create([
            'user_id' => $user->id,
            'status' => 'pending',
            'subtotal' => $priced['subtotal'],
            'discount' => $discount,
            'shipping_fee' => $shipping,
            'total' => $priced['subtotal'] - $discount + $shipping,
            'idempotency_key' => $key,
            'payload_hash' => $hash,
            'shipping_address' => $address->snapshot(),
            'voucher_id' => $voucher?->id,
        ]);

        foreach ($priced['items'] as $line) {
            unset($line['available']);
            $order->items()->create($line);
        }

        return $order->load('items');
    }

    private function claimVoucher(User $user, string $code): Voucher
    {
        $voucher = Voucher::where('code', $code)->where('is_active', true)->first();
        if (! $voucher) {
            throw ValidationException::withMessages(['voucher_code' => 'Voucher tidak valid.']);
        }

        if ($voucher->per_user_limit > 0) {
            $used = Order::where('user_id', $user->id)
                ->where('voucher_id', $voucher->id)
                ->where('status', '!=', 'cancelled')
                ->count();
            if ($used >= $voucher->per_user_limit) {
                throw ValidationException::withMessages(['voucher_code' => 'Batas pemakaian voucher Anda sudah tercapai.']);
            }
        }

        $claimed = Voucher::whereKey($voucher->id)
            ->where('is_active', true)
            ->whereColumn('used', '<', 'quota')
            ->increment('used');
        if ($claimed !== 1) {
            throw ValidationException::withMessages(['voucher_code' => 'Kuota voucher sudah habis.']);
        }

        return $voucher;
    }

    /** Ubah status; stok dan kuota voucher dikembalikan tepat sekali saat transisi ke cancelled. */
    public function transition(Order $order, string $status): Order
    {
        if ($order->status === $status && $status === 'cancelled') {
            return $order;
        }

        if (in_array($status, Order::MANUAL_BLOCKED, true)) {
            throw ValidationException::withMessages(['status' => 'Status paid belum tersedia: sumber bukti pembayaran tepercaya belum diimplementasikan.']);
        }

        if (! $order->canTransitionTo($status)) {
            throw ValidationException::withMessages(['status' => "Status {$order->status} tidak dapat diubah ke {$status}."]);
        }

        DB::transaction(function () use ($order, $status) {
            $updated = Order::whereKey($order->id)->where('status', $order->status)->update(['status' => $status]);
            if ($updated !== 1) {
                abort(409, 'Status pesanan berubah, muat ulang lalu coba lagi.');
            }

            if ($status === 'cancelled') {
                foreach ($order->items as $item) {
                    Product::whereKey($item->product_id)->increment('stock', $item->quantity);
                }
                if ($order->voucher_id) {
                    Voucher::whereKey($order->voucher_id)->where('used', '>', 0)->decrement('used');
                }
            }
        });

        return $order->refresh()->load('items');
    }
}
