# Matriks Ketertelusuran Kebutuhan (Requirements Traceability Matrix)

**Proyek:** ZAFIRA (La Maison de Lumière — `online-shop`)  
**Tanggal:** 2026-10-10  
**Laporan Verifikasi Remediasi Terkait:** [`docs/05-quality/REMEDIATION_VERIFICATION_2026-10-10.md`](../05-quality/REMEDIATION_VERIFICATION_2026-10-10.md) (mencakup FR-201..FR-204 & NFR-201..NFR-203 pasca-remediasi).

**Audit dokumen:** 2026-10-11. Sumber requirement: [PRD](PRD.md) untuk NFR-003 dan [sintesis benchmark](benchmark/SINTESIS_KOMPARATIF_ZAFIRA.md#prioritas-yang-dapat-diuji) untuk FR-201–204/NFR-201–203. Jalur pengguna: [US-001–008 di PRD](PRD.md#3-user-stories-us) dan [journey historis](USER_JOURNEYS.md); keputusan riset: [D-01–08](../research/ZAFIRA_DIFFERENTIATION.md). `NOT RUN` berarti tidak ada test baru dalam audit dokumentasi ini, bukan kegagalan. Test historis yang telah dijalankan tercatat terpisah dalam [ledger eksekusi](../execution/EXECUTION_LEDGER.md); keberadaan source atau test tidak membuktikan semua acceptance lulus. Tautan laporan remediasi di atas adalah laporan historis, bukan review independen saat ini.

---

## Rantai bukti keputusan prioritas

ID S/I/L mengacu pada [register sumber](../research/RESEARCH_METHODOLOGY.md); keputusan D-01–08 pada [diferensiasi](../research/ZAFIRA_DIFFERENTIATION.md). Journey dan US mengacu pada [USER_JOURNEYS](USER_JOURNEYS.md) dan [PRD](PRD.md#3-user-stories-us).

Log PHPUnit hanya merinci total 79 test/428 assertion, bukan hasil per metode. Pemetaan metode berasal dari source test dan cakupan suite; log bukan bukti seluruh acceptance requirement lulus.

Status di bawah memisahkan implementasi/test yang tercatat dari verifikasi yang belum dilakukan. Bukti adalah run historis 2026-10-11, bukan eksekusi baru audit dokumentasi ini.

| Requirement | User story / journey | Finding | Decision | Implementation | Test & evidence | Status |
|---|---|---|---|---|---|---|
| FR-201 | US-003; journey tas/personalisasi | Sintesis Etsy/Shopee; L2 | D-03 Adopt | `resources/js/app.js`; `StorefrontController::bookConcierge` | `tests/task3.test.mjs`, `Task3RemediationTest::test_checkout_persists_valid_size_and_monogram_and_rejects_invalid_monogram`; [Node](../execution/evidence/2026-10-11/phase4/mandate-regression/node-test.log), [PHPUnit](../execution/evidence/2026-10-11/phase4/mandate-regression/phpunit-random.log) | Terimplementasi menurut source; uji historis lulus, bukan dijalankan dalam audit ini. |
| FR-202 | US-002; journey PDP | L8; S7 (Fendi/LV) | D-02 Adapt | `resources/views/products/show.blade.php`; `Product.php` | Test PDP tercatat dalam test suite; [PHPUnit random run](../execution/evidence/2026-10-11/phase4/mandate-regression/phpunit-random.log) | Parsial; acceptance untuk data kosong belum terbukti penuh. |
| FR-203 | US-004; journey concierge | I3, I4, L2, L8; S7 | D-01 Adapt | `StorefrontController::bookConcierge`; `ConciergeRequested` | `StorefrontTest::test_concierge_request_can_be_created`; [PHPUnit random run](../execution/evidence/2026-10-11/phase4/mandate-regression/phpunit-random.log) | Backend queue tercatat; pengiriman email nyata dan seluruh tindak lanjut belum diverifikasi. |
| FR-204 | US-005; journey akun | I3, I4, L2, L8; S7 | D-01 Adapt | `ProfileController.php` | Test account-history di `LegacyPatchTest`; [PHPUnit random run](../execution/evidence/2026-10-11/phase4/mandate-regression/phpunit-random.log) | Uji historis termasuk run acak; belum dijalankan ulang di audit ini. |
| NFR-201 | Semua journey storefront | S8; audit lokal sintesis | D-08 Adopt | `resources/views/welcome.blade.php` | `Task3RemediationTest::test_storefront_hides_prototype_navigation_in_production_but_keeps_assets`; [PHPUnit random run](../execution/evidence/2026-10-11/phase4/mandate-regression/phpunit-random.log) | Uji historis lulus; belum ada run baru. |
| NFR-202 | Semua journey | L2, I3, I4, I5; S7 | D-04 Adapt; D-05 Reject | `resources/views`, `resources/js` | `Task3RemediationTest` dan `tests/task3.test.mjs`; [PHPUnit](../execution/evidence/2026-10-11/phase4/mandate-regression/phpunit-random.log), [Node](../execution/evidence/2026-10-11/phase4/mandate-regression/node-test.log) | Parsial; pencarian menyeluruh atas seluruh klaim belum dibuktikan. |
| NFR-203 | US-001–008; modal lintas journey | S8; audit lokal sintesis | D-08 Adopt | `resources/js/app.js`; `resources/views/welcome.blade.php` | `task4-focus.test.mjs` dan overlay focus-trap tests; [Node run](../execution/evidence/2026-10-11/phase4/mandate-regression/node-test.log), 46/46 lulus | Uji Node untuk fokus/Escape lulus historis. Audit browser lengkap, WCAG 2.2 AA, zoom/mobile dan nama aksesibel belum dijalankan. |

## Matriks Ketertelusuran End-to-End

| Requirement ID | Deskripsi Singkat | User Story Terkait | Modul / File Kode Sumber | Rencana Pengujian (Test Method) | Status Verifikasi |
|---|---|---|---|---|---|
| **FR-001** | Beranda & Hero Editorial ZAFIRA | US-001 | `welcome.blade.php`, `StorefrontController.php` | `StorefrontTest::test_storefront_displays_zafira_brand` | **Historis: Passed diklaim dokumen 10 Oktober; saat ini NOT RUN** |
| **FR-002** | Filter Kategori Dinamis | US-001 | `welcome.blade.php`, `Category.php`, `app.js` | `LegacyPatchTest::test_home_renders_dynamic_category_pills` | **Historis: Passed diklaim dokumen 10 Oktober; saat ini NOT RUN** |
| **FR-003** | Halaman Detail Produk & Kriya | US-002 | `products/show.blade.php`, `StorefrontController.php` | `StorefrontTest::test_product_detail_page_is_accessible` | **Historis: Passed diklaim dokumen 10 Oktober; saat ini NOT RUN** |
| **FR-004** | Tas Belanja & Personalisasi Monogram | US-003 | `resources/js/app.js`, `welcome.blade.php` | `tests/task3.test.mjs` ("legacy cart normalizes variants, collision-safe update/remove survives reload"; lulus dalam [node-test.log](../execution/evidence/2026-10-11/phase4/mandate-regression/node-test.log)); pengujian browser belum ada log terlampir | **Historis: Passed diklaim dokumen 10 Oktober; saat ini NOT RUN** |
| **FR-005** | Mode Checkout Concierge | US-004 | `welcome.blade.php`, `StorefrontController.php` | `StorefrontTest::test_checkout_request_without_schedule_is_valid` | **Historis: Passed diklaim dokumen 10 Oktober; saat ini NOT RUN** |
| **FR-006** | Newsletter Subscription | US-001 | `NewsletterSubscriber.php`, `StorefrontController.php` | `StorefrontTest::test_newsletter_subscription_is_idempotent_with_uniform_response` | **Historis: Passed diklaim dokumen 10 Oktober; saat ini NOT RUN** |
| **FR-007** | Autentikasi Pelanggan & Password Policy | US-005 | `AuthController.php`, `UserObserver.php` | `AuthTest::test_weak_password_is_rejected` | **Historis: Passed diklaim dokumen 10 Oktober; saat ini NOT RUN** |
| **FR-008** | Halaman Profil /akun & Riwayat | US-005 | `ProfileController.php`, `account/show.blade.php` | `LegacyPatchTest::test_user_can_view_and_update_profile` | **Historis: Passed diklaim dokumen 10 Oktober; saat ini NOT RUN** |
| **FR-009** | Login Guard Khusus Admin | US-006 | `AdminAuthController.php`, `admin/login.blade.php` | `LegacyPatchTest::test_admin_can_login_and_view_dashboard` | **Historis: Passed diklaim dokumen 10 Oktober; saat ini NOT RUN** |
| **FR-010** | Dashboard Workspace & KPI Metrik | US-006 | `AdminDashboardController.php`, `admin/dashboard.blade.php` | `AdminManagementTest::test_concierge_checkout_with_order_items...` | **Historis: Passed diklaim dokumen 10 Oktober; saat ini NOT RUN** |
| **FR-011** | Manajemen Katalog Produk & Kriya | US-007 | `AdminProductController.php`, `Product.php` | `AdminManagementTest::test_admin_can_create_new_product` | **Historis: Passed diklaim dokumen 10 Oktober; saat ini NOT RUN** |
| **FR-012** | Manajemen Kategori & Cache Flush | US-007 | `AdminCategoryController.php`, `Category.php` | `LegacyPatchTest::test_admin_can_manage_categories` | **Historis: Passed diklaim dokumen 10 Oktober; saat ini NOT RUN** |
| **FR-013** | Pembaruan Alur Status Pesanan | US-008 | `AdminDashboardController.php`, `ConciergeRequest.php` | `LegacyPatchTest::test_admin_can_update_concierge_status` | **Historis: Passed diklaim dokumen 10 Oktober; saat ini NOT RUN** |
| **FR-014** | Penggantian Kata Sandi Admin | US-006 | `AdminDashboardController.php`, `Admin.php` | `LegacyPatchTest::test_admin_can_change_password` | **Historis: Passed diklaim dokumen 10 Oktober; saat ini NOT RUN** |
| **NFR-001** | Performa & Caching Storefront | All | `app/Http/Controllers/StorefrontController.php` (cache TTL 300s; kebijakan LRU tidak dibuktikan) | PRD: rata-rata storefront < 150ms dan aset Gzip < 120 kB; [ledger](../execution/EXECUTION_LEDGER.md) mencatat CSS 21.79 + JS 6.46 = 28.25 kB | **PARTIAL — ukuran aset historis memenuhi target; latensi belum diukur. Tidak ada run baru.** |
| **NFR-002** | Keamanan HTTP Headers & CSRF | All | `SecurityHeaders.php`, `bootstrap/app.php` | Assertion header pada seluruh rute respons | **Historis: Passed diklaim dokumen 10 Oktober; saat ini NOT RUN** |
| **NFR-003** | Integritas data relasional | All | `database/migrations/2026_09_07_034058_create_products_table.php` (`product_cat`→`categories`); `2026_09_14_000006_add_user_id_to_concierge_requests_table.php` (`user_id`→`users`, `nullOnDelete`); migrasi `user_info_backups` (`user_id`→`users`) | Inspeksi constraint migration; bukan bukti skema database aktif | **FAIL (requirement relasi pesanan) — tiga FK terdefinisi di migration (bukti parsial produk/kategori/user). Tidak ada tabel Order; item pesanan concierge tidak dimodelkan relasional sehingga relasi pesanan yang diwajibkan PRD tidak terbukti. Test belum dijalankan pada sesi audit ini.** |
| **NFR-004** | Konsistensi Visual Atelier | All | `resources/css/app.css`, Unified Admin Layout | Penilaian Desain & Browser Testing | **Historis: peningkatan Fase 6 diklaim; audit visual saat ini NOT RUN** |
| **NFR-005** | Kompatibilitas Lingkungan macOS | All | `composer.json`, `package.json`, Vite, MariaDB | CLI execution, test suite | **BELUM DIVERIFIKASI pada audit dokumentasi ini; tidak ada test dijalankan.** |
| **FR-201** | Varian ukuran dan monogram melekat pada item tas dan payload concierge | US-003 | `resources/js/app.js`; `StorefrontController::bookConcierge` | `tests/task3.test.mjs`; `Task3RemediationTest::test_checkout_persists_valid_size_and_monogram_and_rejects_invalid_monogram` | **Terimplementasi menurut source/test; tidak dijalankan pada sesi audit ini.** |
| **FR-202** | PDP menyajikan panduan ukuran, material, dan perawatan yang didukung data | US-002 | `resources/views/products/show.blade.php`; `Product.php` | `BrandHeritageTest` dan pemeriksaan feature PDP; kriteria tanpa data perlu test khusus | **Parsial — field dan tampilan ada; seluruh acceptance belum dibuktikan. Tidak ada run baru pada audit ini; bukti historis ada di rantai bukti.** |
| **FR-203** | Permintaan concierge berhasil hanya setelah backend menerima dan memberi tindak lanjut yang didukung | US-004 | `StorefrontController::bookConcierge`; `ConciergeRequested` | `StorefrontTest::test_concierge_request_can_be_created`; `test_checkout_request_without_schedule_is_valid` | **Terimplementasi menurut source/test; email dimasukkan antrean setelah create; pengiriman nyata belum diverifikasi. Tidak ada run baru pada audit ini; bukti historis ada di rantai bukti.** |
| **FR-204** | Akun menampilkan permintaan milik pengguna dan status yang tersimpan | US-005 | `ProfileController.php`; `LegacyPatchTest` | `test_account_history_excludes_guest_and_other_user_rows_with_matching_email`; `test_account_history_prefers_user_id_link` | **Terimplementasi menurut source/test; tidak ada run baru pada audit ini; bukti historis ada di rantai bukti.** |
| **NFR-201** | Navigasi prototype disembunyikan di produksi; aset storefront tetap tersedia | All | `resources/views/welcome.blade.php` | `Task3RemediationTest::test_storefront_hides_prototype_navigation_in_production_but_keeps_assets` | **Terimplementasi menurut source/test; tidak ada run baru pada audit ini; bukti historis ada di rantai bukti.** |
| **NFR-202** | UI tidak membuat klaim operasional/keaslian atau mata uang tanpa dukungan data | All | `resources/views`, `resources/js`, kamus runtime | `Task3RemediationTest::test_product_and_account_pages_do_not_claim_fake_certificates_or_profile_data`; `tests/task3.test.mjs` | **Parsial — subset klaim diuji; belum mencakup pencarian menyeluruh. Tidak ada run baru pada audit ini; bukti historis ada di rantai bukti.** |
| **NFR-203** | Interaksi dan modal dapat digunakan dengan keyboard, nama aksesibel, fokus, dan Escape | All | `resources/js/app.js`; `resources/views/welcome.blade.php` | `tests/task3.test.mjs` (Escape/lifecycle sebagian); audit keyboard/browser dan WCAG diperlukan | **Parsial — uji Node fokus/Escape lulus historis (lihat rantai bukti); audit browser penuh, nama aksesibel dan WCAG belum terbukti. Tidak ada run baru.** |

## Adendum rekonsiliasi 12 Oktober 2026 (status terkini)

Dibaca: `final-regression-3` (full suite terbaru, **sebelum dock CSS**: PHP 101/576 standar+acak, Node 56/56, build dan diff exit 0; Pint awal gagal hanya berkas bukti QA, lalu `pint3-rerun.log` PASS), `final-regression-4` (pasca-dock: build, Pint seluruh repo, diff exit 0; PHP tidak diulang karena CSS-only), Node run8 57/57, sweep-8 (56/56), dock-run8, `drawer-interactions-run7`, `overlay-run7` (174/174), review independen run7 dilaporkan lulus, dan `final-regression-2` session/throttle (historis, tetap berlaku). Tidak ada deployment. Status ini menggantikan "NOT RUN" lama hanya untuk area berikut; tabel per-ID di atas dan adendum 11 Oktober tetap riwayat.

| Kebutuhan / area | Status terkini | Catatan |
|---|---|---|
| FR-001 beranda | PASS terbatas / NOT RUN acceptance tersisa | Brand/render teruji pada suite dan sweep-7; LRU tidak dibuktikan. |
| FR-002 filter | PASS terbatas | Node filter kategori+pencarian lulus di node3; seluruh jalur browser belum terbukti. |
| FR-003 PDP | PASS terbatas / NOT RUN acceptance tersisa | Route/PDP teruji; tiga produk terkait dan seluruh acceptance konten belum terbukti. |
| FR-004 / FR-201 tas dan varian | PASS terbatas | Node normalisasi/persistensi, PHP validasi payload, overlay cart; bukan transaksi end-to-end produksi. |
| FR-005 / FR-203 concierge | PASS create+queue / NOT RUN delivery | PHP dan HTTP browser ber-CSRF; form publik click-path dan pengiriman email nyata belum diuji. |
| FR-006 newsletter | PASS create/duplicate / NOT RUN delivery | completion-backend HTTP browser; bukan bukti email terkirim atau submit form publik. |
| FR-007 autentikasi pelanggan | PASS terbatas | Suite AuthTest, browser login/logout terdahulu; verifikasi email bukan fitur aktif. |
| FR-008 / FR-204 profil dan riwayat | PASS perilaku `user_id`, BLOCKED kontrak | Profil UI teruji completion-backend; email-match PRD tetap konflik, bukan penerimaan penuh. |
| FR-009 admin guard | PASS terbatas | Login/redirect/permission teruji suite dan completion-backend. |
| FR-010 dashboard/KPI | PARTIAL | Dashboard/transisi UI teruji; seluruh ketepatan KPI belum dibuktikan. |
| FR-011 katalog | PARTIAL / BLOCKED kontrak cache | Create/delete teruji; product update UI dan klik Accept destructive belum diuji. |
| FR-012 kategori | PASS terbatas | Create/update/proteksi kategori berisi produk teruji; kontrak cache perlu keputusan. |
| FR-013 status concierge | PASS terbatas | Jalur utama dan pembatalan browser; backend menolak transisi tidak sah. Semua edge browser belum diuji. |
| FR-014 password admin | PASS perubahan / BLOCKED round 12 | Suite mencakup ganti password; bcrypt 12 belum terverifikasi. |
| FR-202 data PDP | PARTIAL / NOT RUN data kosong | Data/tampilan ada; acceptance fallback kosong belum punya bukti khusus. |
| NFR-201 nav prototype produksi | PASS terbatas | Task3RemediationTest pada php-default3; bukan deployment aktual. |
| NFR-202 klaim operasional | PARTIAL | Subset klaim dan IDR teruji Node/PHP; audit seluruh klaim NOT RUN. |
| NFR-004 visual | PARTIAL / FAIL dock desktop | Sweep-8 lokal 56/56 lulus; tidak semua screenshot sweep8 diperiksa visual. |
| NFR-005 macOS | PASS lingkungan ini / NOT RUN matriks setup | PHP/build/Node berjalan pada host ini; bukan semua instalasi macOS/arm64. |
| NFR-301 isolasi fixture | PASS terbatas | Suite standar+acak final-regression-3 lulus; SQLite bukan kompatibilitas routine MariaDB. |
| NFR-203 fokus/Escape | PASS terbatas | Overlay storefront 174/174, drawer prototype run7, review independen run7 dilaporkan lulus; artefak laporan reviewer tidak ditemukan. WCAG 2.2 AA penuh NOT RUN. |
| NFR-203 kontras | PARTIAL | Satu pasangan solid `.cat-pill.active` 19.05:1; sisanya NOT RUN. |
| NFR-203 target sentuh | PARTIAL residual | Ikon header 37×37px dan kontrol lain <44px (sweep7/sweep8, daftar terpotong). |
| NFR-203/NFR-004 dock mobile | PASS terbatas | Riwayat: overlap 390px 3.40625px (scroll 0) dan 52.1875px (scroll 50). `dock-run8-final.json`: 0px pada 320/390/768 di scroll 0/50/150/500. |
| NFR-203/NFR-004 dock desktop 1366×768 | FAIL residual | `dock-run8-final.json` dan `dock-run8-verified.json`: overlap 21px di scroll 0; verified exit 0 hanya karena pengecualian skrip. Inspeksi visual 1366 NOT RUN. |
| NFR-002 sesi dua guard | PASS terbatas | Replay file-session ditolak (historis final-regression-2); bukan alur browser penuh. |
| NFR-002 throttle concierge | PASS terbatas | 422×3 lalu 429×2 file cache; login throttle tidak dibuktikan; produksi/proxy belum. |
| NFR-002 CSP | OPEN | Source tidak memasang CSP/report-only. `csp3-summary.md` hanya harness Playwright report-only; ada violation inline dan tidak dideploy. |
| NFR-001 latensi | BLOCKED (konflik 100 vs 150 ms) | LCP lokal sweep-8 ≤716ms bukan latensi server. |
| FR-008 vs FR-204 | BLOCKED (kepemilikan vs email) | Pemilik harus memutuskan. |
| FR-011/FR-012 cache | BLOCKED (`Cache::flush()` vs `forget`) | |
| FR-014 bcrypt 12 | BLOCKED/unverified | |
| NFR-003 Order FK | FAIL | Tidak ada tabel Order. |
| Verifikasi email (`MustVerifyEmail`) | NA | Tidak diimplementasikan; bukan klaim PASS. |
| Riset S1–S8 | PASS sumber | Konten dibaca; bukan HTTP-only. Storefront kompetitor BLOCKED. |
| Kesiapan | Lokal/demo bersyarat; produksi TIDAK SIAP | |

## Adendum status audit riset (2026-10-11)

Vokabulari: `PASS` (acceptance teruji dengan bukti), `FAIL`, `BLOCKED`, `NOT RUN`, `NA`. Adendum ini tidak mengubah requirement kanonis. Detail dan sumber: [audit riset akhir](../research/FINAL_DIRECTIVE_RESEARCH_AUDIT.md), [ekstrak sumber](../execution/evidence/2026-10-11/phase4/completion-research/source-excerpts.md). Log historis PHPUnit 79/428 dan Node 46/46 tidak dijalankan ulang di sini; bukan bukti semua acceptance.

| Kebutuhan | Need/Sumber | Desain | Implementasi | Test/bukti | Status |
|---|---|---|---|---|---|
| FR-201 | S7 (Fendi/ukuran); D-03 | Varian melekat pada tas | `app.js`; `bookConcierge` | `Task3RemediationTest`, `task3.test.mjs`; log mandate-regression | PASS untuk payload ukuran/monogram teruji; browser E2E tidak dijalankan |
| FR-202 | S7; D-02 | PDP material/ukuran/perawatan | `products/show.blade.php` | tidak ada test data-kosong khusus | NOT RUN |
| FR-203 | S7; D-01 | Backend menerima lalu antre email | `bookConcierge` | `StorefrontTest` memakai `Mail::fake()`; email nyata tidak diuji | PASS untuk create+queue; NOT RUN untuk delivery |
| FR-204/FR-008 | D-01 | Riwayat milik user | `ProfileController` | `LegacyPatchTest` account-history; PRD FR-008 menyebut kecocokan email | Konflik acceptance; PASS untuk perilaku FR-204 yang diuji, FR-008 email-match NOT RUN |
| NFR-201 | D-08 | Sembunyikan nav prototype | `welcome.blade.php` | `Task3RemediationTest` | PASS (test historis) |
| NFR-202 | D-04/D-05 | Tanpa klaim palsu | views/js | subset test | NOT RUN untuk pencarian menyeluruh |
| NFR-203 | S8; D-08 | Fokus/Escape/WCAG | `app.js`, views | Node 46/46 parsial | NOT RUN untuk WCAG 2.2 AA penuh |
| NFR-001 | PRD | Latensi; objective `<100ms` vs `<150ms` | `StorefrontController` | hanya ukuran aset | NOT RUN; requirement konflik |
| NFR-003 | PRD | FK order | migrations | tidak ada tabel Order | FAIL |
| FR-014 | PRD | Bcrypt round 12 | `AdminDashboardController` | round tidak terbukti | NOT RUN |
| Kompetitor terblokir | S-register | Observasi saja | — | CAPTCHA/403/Cloudflare/timeout/cert | BLOCKED |
| Latensi/aksesibilitas dari asset bytes | — | — | — | tidak ada pengukuran | NA sebagai klaim lulus |
