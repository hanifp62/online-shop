import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

// Regression: overlapping cart mutations were silently dropped while a request was in flight
// (cartRequest returned null when busy). Each action must apply, using fresh cart state.
const app = readFileSync(new URL('../resources/js/app.js', import.meta.url), 'utf8').replace(/^import .*;\n/gm, '');

function node(dataset = {}) {
    const classes = new Set();
    const handlers = {};
    return {
        dataset, handlers, children: [], style: {}, hidden: false, textContent: '',
        classList: { contains: (c) => classes.has(c), add: (c) => classes.add(c), remove: (c) => classes.delete(c), toggle(c, on = !classes.has(c)) { on ? classes.add(c) : classes.delete(c); return on; } },
        addEventListener(type, fn) { (handlers[type] ??= []).push(fn); },
        fire(type, event = {}) { for (const fn of handlers[type] ?? []) fn(event); },
        setAttribute(key, value) { this[key] = value; },
        querySelector(selector) { return this.children.find((child) => selector === '[data-toast-action]' && child.dataset?.toastAction !== undefined) ?? null; }, querySelectorAll() { return []; },
        appendChild(child) { this.children.push(child); }, replaceChildren() { this.children = []; },
        focus() {},
    };
}

function storefront() {
    const elements = new Map();
    for (const s of ['.storefront', '[data-cart-items]', '[data-cart-empty]', '[data-cart-footer]', '[data-cart-status]', '.toast']) elements.set(s, [node()]);
    const card = node({ id: 'bag', productId: '7', name: 'Tas Kulit', category: 'Tas', price: '200' });
    const addButton = node();
    addButton.closest = () => card;
    elements.set('[data-product-card]', [card]);
    elements.set('[data-card-add]', [addButton]);
    const document = node();
    document.body = node();
    document.activeElement = node();
    document.querySelector = (s) => elements.get(s)?.[0] ?? null;
    document.querySelectorAll = (s) => elements.get(s) ?? [];
    document.createElement = () => node();
    const requests = [];
    const fetch = (url, options) => new Promise((resolve) => {
        requests.push({ url, method: options.method, body: options.body ? JSON.parse(options.body) : null, respond: (data, ok = true) => resolve({ ok, json: async () => data }) });
    });
    const window = node();
    window.location = { href: 'https://zafira.test/', search: '' };
    const context = { document, window, navigator: {}, fetch, localStorage: { getItem: () => null, setItem() {}, removeItem() {} }, URL, URLSearchParams, history: { replaceState() {} }, setTimeout() {}, clearTimeout() {} };
    vm.runInNewContext(app, context);
    const items = elements.get('[data-cart-items]')[0];
    const toast = elements.get('.toast')[0];
    return {
        requests,
        status: elements.get('[data-cart-status]')[0],
        addButton,
        undo: () => toast.querySelector('[data-toast-action]').onclick(),
        click(action) {
            const row = items.children[0];
            items.fire('click', { target: { closest: (s) => (s === '[data-cart-id]' ? row : s === '[data-remove-cart]' ? action === 'remove' : { dataset: { quantity: action } }) } });
        },
    };
}

const flush = () => new Promise((resolve) => setImmediate(resolve));
const cartOf = (quantity) => ({ items: quantity ? [{ product_id: 7, product_title: 'Tas Kulit', unit_price: 200, quantity, available: true }] : [], subtotal: quantity * 200 });

test('rapid adds during a slow request are serialized with fresh quantities, not dropped', async () => {
    const h = storefront();
    await flush();
    h.requests[0].respond(cartOf(0));
    await flush();

    h.addButton.fire('click');
    h.addButton.fire('click');
    await flush();
    assert.equal(h.requests.length, 2, 'second add waits instead of firing in parallel');
    assert.equal(h.requests[1].body.quantity, 1);

    h.requests[1].respond(cartOf(1));
    await flush();
    assert.equal(h.requests.length, 3, 'second add was not silently dropped');
    assert.equal(h.requests[2].body.quantity, 2, 'quantity computed after first response, not before');
});

test('rapid quantity clicks apply each step and stop once the line is gone', async () => {
    const h = storefront();
    await flush();
    h.requests[0].respond(cartOf(2));
    await flush();

    h.click('plus');
    h.click('plus');
    await flush();
    assert.deepEqual(h.requests.slice(1).map((r) => r.body.quantity), [3]);
    h.requests[1].respond(cartOf(3));
    await flush();
    assert.equal(h.requests[2].body.quantity, 4);
    h.requests[2].respond(cartOf(4));
    await flush();

    const h2 = storefront();
    await flush();
    h2.requests[0].respond(cartOf(1));
    await flush();
    h2.click('minus');
    h2.click('minus');
    await flush();
    assert.equal(h2.requests[1].method, 'DELETE');
    h2.requests[1].respond(cartOf(0));
    await flush();
    assert.equal(h2.requests.length, 2, 'second minus on a removed line sends nothing');
    assert.notEqual(h2.status.textContent, 'Memproses…', 'status not left stuck on Memproses after null-intent');
});

test('a failed request does not block later actions; undo still restores removed quantity', async () => {
    const h = storefront();
    await flush();
    h.requests[0].respond(cartOf(2));
    await flush();

    h.click('plus');
    h.click('remove');
    await flush();
    h.requests[1].respond({ message: 'Stok habis.' }, false);
    await flush();
    assert.equal(h.requests[2].method, 'DELETE', 'queue continues after failure');
    h.requests[2].respond(cartOf(0));
    await flush();

    h.undo();
    await flush();
    assert.equal(h.requests[3].method, 'POST');
    assert.deepEqual(h.requests[3].body, { product_id: 7, quantity: 2 }, 'undo restores quantity the server actually removed');
});

test('remove queued behind a successful plus undoes to the updated quantity', async () => {
    const h = storefront();
    await flush();
    h.requests[0].respond(cartOf(2));
    await flush();

    h.click('plus');
    h.click('remove');
    await flush();
    h.requests[1].respond(cartOf(3));
    await flush();
    h.requests[2].respond(cartOf(0));
    await flush();
    h.undo();
    await flush();
    assert.deepEqual(h.requests[3].body, { product_id: 7, quantity: 3 });
});
