import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const app = readFileSync(new URL('../resources/js/app.js', import.meta.url), 'utf8').replace(/^import .*;\n/gm, '');
const welcome = readFileSync(new URL('../resources/views/welcome.blade.php', import.meta.url), 'utf8');
const prototypeApp = readFileSync(new URL('../prototype/app.js', import.meta.url), 'utf8');

test('prototype product links resolve storefront slugs', () => {
    assert.match(prototypeApp, /item\.slug === requestedProductId \|\| item\.id === numericId/);
});
function node(dataset = {}) {
    const classes = new Set();
    const handlers = {};
    return {
        dataset, handlers, children: [], style: {}, hidden: false, value: '', textContent: '',
        classList: { contains: (c) => classes.has(c), add: (c) => classes.add(c), remove: (c) => classes.delete(c), toggle(c, on = !classes.has(c)) { on ? classes.add(c) : classes.delete(c); return on; } },
        addEventListener(type, fn) { (handlers[type] ??= []).push(fn); },
        fire(type, event = {}) { for (const fn of handlers[type] ?? []) fn(event); },
        setAttribute(key, value) { this[key] = value; },
        querySelector() { return null; }, querySelectorAll() { return []; },
        appendChild(child) { this.children.push(child); }, replaceChildren(...next) { this.children = next; },
        focus() {}, scrollIntoView() {},
        set innerHTML(value) { this.children = []; this.html = value; }, get innerHTML() { return this.html ?? ''; },
    };
}
const CATALOG = { 11: { product_title: 'Robe Sutra', unit_price: 100 }, 22: { product_title: 'Tas Kulit', unit_price: 200 } };
// Deterministic fake of the session cart API: POST /cart/items SETs quantity, DELETE removes, GET reads.
function fakeServer(initial = []) {
    const lines = new Map(initial.map((line) => [line.product_id, { ...line }]));
    const calls = [];
    const payload = () => {
        const items = [...lines.values()].map((line) => ({ available: true, ...CATALOG[line.product_id], ...line }));
        return { items, subtotal: items.reduce((sum, i) => sum + i.unit_price * i.quantity, 0) };
    };
    const fetch = async (url, init = {}) => {
        const method = init.method || 'GET';
        const body = init.body ? JSON.parse(init.body) : null;
        calls.push({ url, method, body });
        if (method === 'POST' && url === '/cart/items') lines.set(body.product_id, { product_id: body.product_id, quantity: body.quantity });
        const removed = method === 'DELETE' && url.match(/^\/cart\/items\/(\d+)$/);
        if (removed) lines.delete(Number(removed[1]));
        return { ok: true, json: async () => payload() };
    };
    return { fetch, calls, snapshot: () => [...lines.values()].map((line) => ({ ...line })), writes: () => calls.filter((c) => c.method !== 'GET') };
}
function storefront({ server = fakeServer(), legacy = {} } = {}) {
    const elements = new Map();
    for (const selector of ['.storefront', '[data-overlay]', '.cart-drawer', '.search-panel', '.quick-view-modal', '.concierge-modal', '#welcome-profile-drawer', '[data-cart-items]', '[data-cart-empty]', '[data-cart-footer]', '[data-product-count]', '.empty-products', '#live-catalog-search-input', '#welcome-feedback-strip', '[data-legacy-cart]', '[data-legacy-lines]']) elements.set(selector, [node()]);
    const cards = [node({ id: 'robe', productId: '11', name: 'Robe Sutra', category: 'Busana', material: 'Sutra', price: '100' }), node({ id: 'bag', productId: '22', name: 'Tas Kulit', category: 'Tas', material: 'Kulit', price: '200' })];
    elements.set('[data-product-card]', cards);
    const filters = ['Semua', 'Busana', 'Tas'].map((filter) => node({ filter }));
    elements.set('[data-filter]', filters);
    const addButtons = cards.map((card) => { const button = node(); button.closest = () => card; return button; });
    elements.set('[data-card-add]', addButtons);
    for (const selector of ['[data-open-cart]', '[data-open-profile]', '[data-close-profile]', '[data-open-concierge]']) elements.set(selector, [node()]);
    const document = node();
    document.body = node(); document.activeElement = node();
    document.querySelector = (s) => elements.get(s)?.[0] ?? null;
    document.querySelectorAll = (s) => elements.get(s) ?? [];
    document.createElement = () => node();
    const values = new Map(Object.entries(legacy));
    const storageWrites = [];
    const window = node();
    window.location = { href: 'https://zafira.test/', search: '' };
    const localStorage = {
        getItem: (k) => values.get(k) ?? null,
        setItem: (k, v) => { storageWrites.push(['set', k]); values.set(k, v); },
        removeItem: (k) => { storageWrites.push(['remove', k]); values.delete(k); },
    };
    const context = { document, window, navigator: {}, localStorage, fetch: server.fetch, URL, URLSearchParams, history: { replaceState() {} }, setTimeout() {}, clearTimeout() {} };
    vm.runInNewContext(app, context);
    // The fake fetch only resolves through microtasks, so one macrotask turn drains the whole queued cart chain.
    const settle = () => new Promise((resolve) => setImmediate(resolve));
    return { document, window, cards, filters, addButtons, server, values, storageWrites, settle, get: (s) => elements.get(s)[0], rows: () => elements.get('[data-cart-items]')[0].children };
}
function cartClick(h, index, action) {
    const row = h.get('[data-cart-items]').children[index];
    const button = action === 'remove' ? null : { dataset: { quantity: action } };
    h.get('[data-cart-items]').fire('click', { target: { closest: (s) => s === '[data-cart-id]' ? row : s === '[data-remove-cart]' ? action === 'remove' : button } });
}

test('legacy cart keys stay untouched, are never auto-posted, and never merge into the server cart', async () => {
    const v1 = JSON.stringify([{ id: 'robe', name: 'Robe Sutra', size: 'M', monogram: 'AB', quantity: 2 }]);
    const unversioned = JSON.stringify([{ id: 'bag', quantity: 1 }, { id: 'scarf', name: 'Selendang', quantity: 3 }]);
    const h = storefront({ legacy: { 'zafira-cart:v1': v1, 'zafira-cart': unversioned } });
    await h.settle();
    // Both keys survive byte-for-byte: no migration, rewrite, or deletion.
    assert.equal(h.values.get('zafira-cart:v1'), v1);
    assert.equal(h.values.get('zafira-cart'), unversioned);
    assert.deepEqual(h.storageWrites, []);
    // Only the initial server read happened: no automatic POST/DELETE of legacy lines.
    assert.deepEqual(h.server.calls, [{ url: '/cart', method: 'GET', body: null }]);
    assert.deepEqual(h.server.snapshot(), []);
    assert.equal(h.rows().length, 0);
    // Legacy lines are shown read-only for the customer instead.
    assert.equal(h.get('[data-legacy-cart]').hidden, false);
    assert.deepEqual(h.get('[data-legacy-lines]').children.map((li) => li.textContent), [
        'Robe Sutra × 2 · Ukuran: M · Monogram: AB',
        'bag × 1',
        'Selendang × 3',
    ]);
});

test('server cart renders by product_id, quantity edits SET server quantity, and a fresh harness restores from server state', async () => {
    const h = storefront({ server: fakeServer([{ product_id: 11, quantity: 2 }, { product_id: 22, quantity: 1 }]) });
    await h.settle();
    assert.deepEqual(h.rows().map((row) => row.dataset.cartId), ['11', '22']);
    cartClick(h, 0, 'plus');
    await h.settle();
    assert.deepEqual(h.server.writes(), [{ url: '/cart/items', method: 'POST', body: { product_id: 11, quantity: 3 } }]);
    cartClick(h, 1, 'minus');
    await h.settle();
    assert.deepEqual(h.server.writes().at(-1), { url: '/cart/items/22', method: 'DELETE', body: null });
    assert.deepEqual(h.server.snapshot(), [{ product_id: 11, quantity: 3 }]);

    const reload = storefront({ server: fakeServer(h.server.snapshot()) });
    await reload.settle();
    assert.deepEqual(reload.rows().map((row) => row.dataset.cartId), ['11']);
    assert.match(reload.rows()[0].innerHTML, /<span>3<\/span>/);
    cartClick(reload, 0, 'remove');
    await reload.settle();
    assert.deepEqual(reload.server.writes(), [{ url: '/cart/items/11', method: 'DELETE', body: null }]);
    assert.equal(reload.rows().length, 0);
    assert.deepEqual(h.values.size, 0); // the cart never touches localStorage
});

test('catalog search and category intersect through one hidden-based filter', () => {
    const h = storefront();
    const input = h.get('#live-catalog-search-input');
    input.value = 'sutra'; input.fire('input');
    assert.deepEqual(h.cards.map((c) => c.hidden), [false, true]);
    h.filters[2].fire('click');
    assert.deepEqual(h.cards.map((c) => c.hidden), [true, true]);
    assert.equal(String(h.get('[data-product-count]').textContent), '0');
    input.value = ''; input.fire('input');
    assert.deepEqual(h.cards.map((c) => c.hidden), [true, false]);
    assert.ok(!welcome.includes('card.style.display'));
});

test('profile shares overlay and scroll lifecycle with cart and concierge', () => {
    const h = storefront();
    h.get('[data-open-profile]').fire('click');
    assert.ok(h.get('#welcome-profile-drawer').classList.contains('open'));
    assert.ok(h.document.body.classList.contains('no-scroll'));
    h.get('[data-open-cart]').fire('click');
    h.get('[data-close-profile]').fire('click');
    assert.ok(h.get('[data-overlay]').classList.contains('open'));
    assert.ok(h.document.body.classList.contains('no-scroll'));
    h.get('[data-open-concierge]').fire('click');
    h.get('[data-overlay]').fire('click');
    assert.ok(!h.document.body.classList.contains('no-scroll'));
    h.get('[data-open-profile]').fire('click');
    h.document.fire('keydown', { key: 'Escape' });
    assert.equal(h.get('#welcome-profile-drawer')['aria-hidden'], 'true');
    assert.ok(!h.get('[data-overlay]').classList.contains('open'));
    assert.ok(!h.document.body.classList.contains('no-scroll'));
    assert.ok(!welcome.includes('document.body.style.overflow'));
    assert.ok(!welcome.includes("e.key === 'Escape'"));
});

test('standard card add POSTs server product_id with SET quantity and survives a fresh harness', async () => {
    const h = storefront();
    await h.settle();
    h.addButtons[1].fire('click');
    await h.settle();
    h.addButtons[1].fire('click');
    await h.settle();
    assert.deepEqual(h.server.writes(), [
        { url: '/cart/items', method: 'POST', body: { product_id: 22, quantity: 1 } },
        { url: '/cart/items', method: 'POST', body: { product_id: 22, quantity: 2 } },
    ]);
    assert.deepEqual(h.rows().map((row) => row.dataset.cartId), ['22']);

    // Fresh page load with the server state as supplied: next add continues from the server quantity.
    const reload = storefront({ server: fakeServer(h.server.snapshot()) });
    await reload.settle();
    assert.deepEqual(reload.rows().map((row) => row.dataset.cartId), ['22']);
    reload.addButtons[1].fire('click');
    await reload.settle();
    assert.deepEqual(reload.server.writes(), [{ url: '/cart/items', method: 'POST', body: { product_id: 22, quantity: 3 } }]);
});

test('apparel card add still goes to the PDP and never writes to the server cart', async () => {
    const h = storefront();
    await h.settle();
    h.addButtons[0].fire('click');
    await h.settle();
    assert.equal(h.window.location.href, '/produk/robe');
    assert.deepEqual(h.server.writes(), []);
});

test('runtime translations cannot restore removed claims in any language', () => {
    const source = readFileSync(new URL('../public/js/zafira-core.js', import.meta.url), 'utf8');
    const start = source.indexOf('const I18N =');
    const end = source.indexOf('// --- 2.', start);
    const dict = vm.runInNewContext(`${source.slice(start, end)}; I18N`);
    for (const [lang, translations] of Object.entries(dict)) {
        assert.ok(!/certificat|certificato|certificate|sertifikat/i.test(translations.service_4_title), lang);
        assert.ok(!/3.?5|3 à 5|3 a 5/.test(translations.atelier_step_3), lang);
        assert.match(translations.toast_rendezvous_registered, /simula/i);
        for (const key of Object.keys(translations)) assert.ok(!/^(telemetry_|account_cert|account_step_|profile_(advisor|silhouette|registered_size|chest_waist|vic_badge))/.test(key), `${lang}:${key}`);
    }
    assert.ok(!welcome.includes('Madame Aurelia'));
    assert.ok(!welcome.includes('(3–5 hari)'));
});

test('both runtime dictionaries omit unsupported claims and keep four languages', () => {
    for (const path of ['../public/js/zafira-core.js', '../prototype/zafira-core.js']) {
        const source = readFileSync(new URL(path, import.meta.url), 'utf8');
        const dictionary = vm.runInNewContext(`${source.slice(source.indexOf('const I18N ='), source.indexOf('// --- 2.'))}; I18N`);
        assert.deepEqual(Object.keys(dictionary).sort(), ['en', 'fr', 'id', 'it'], path);
        const productBlock = source.slice(source.indexOf('const MULTI_PRODUCTS'), source.indexOf('// Cross-reference aliases'));
        assert.doesNotMatch(productBlock, /\b(?:60 hours|60 jam|soixante heures|sessanta ore|3 minggu|12 jam|twelve hours|douze heures|dodici ore|24k|serial|nomor seri|numéro de série|numero di serie|measurements:)\b/i, path);
        for (const translations of Object.values(dictionary)) {
            assert.doesNotMatch(JSON.stringify(translations), /\b(?:MSI|telemetry|18k|18 karat|18 carats|18 carati|24k|certificate|certificat|certificato|sertifikat|serial|advisor|takt time|throughput|ledger)\b/i, path);
        }
    }
});
