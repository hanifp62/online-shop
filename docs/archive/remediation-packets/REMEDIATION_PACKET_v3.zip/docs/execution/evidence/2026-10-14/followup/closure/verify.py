#!/usr/bin/env python3
"""Execute isolated closure checks; operational configuration is never loaded."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
from run import run, OUT

REPO = OUT.parents[5]
ROOT = Path('/private/var/folders/3n/g8p6ncc153dcc72zmv1bff9m0000gn/T/opencode/zafira-manual-closure-20261015')
env = os.environ.copy()
for key in list(env):
    if key.startswith(('APP_', 'DB_', 'DATABASE_', 'LARAVEL_', 'SESSION_', 'CACHE_', 'QUEUE_', 'MAIL_', 'REDIS_', 'MEMCACHED_', 'AWS_', 'FILESYSTEM_', 'BROADCAST_', 'LOG_', 'AMADIS_', 'PHP_', 'VIEW_', 'ADMIN_SEED_', 'MANUAL_CUSTOMER_')) or key in ('PHPRC', 'XDEBUG_CONFIG', 'XDEBUG_MODE'):
        del env[key]
env.update(MANUAL_ROOT=str(ROOT), MANUAL_PORT='8018')

def hashes():
    paths = []
    for directory in ('app', 'resources', 'routes', 'tests', 'config', 'database/migrations', 'scripts/manual'):
        paths.extend(p for p in (REPO / directory).rglob('*') if p.is_file())
    return {str(p.relative_to(REPO)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}

if __name__ == '__main__':
    before = hashes()
    (OUT / 'source-pre.json').write_text(json.dumps(before, indent=2))
    for label, cmd in [('php-version', ['php', '--version']), ('node-version', ['node', '--version']), ('npm-version', ['npm', '--version'])]:
        run(label, cmd, ROOT, env)
    assert run('preflight', ['python3', 'scripts/manual/preflight.py', 'fixture'], ROOT, env) == 0
    assert run('fixture-1', ['bash', 'scripts/manual/fixture.sh'], ROOT, env) == 0
    assert run('fixture-2', ['bash', 'scripts/manual/fixture.sh'], ROOT, env) == 0
    # PHPUnit overrides local disposable DB with in-memory SQLite; only isolated .env can be read.
    testenv = env | {'APP_ENV': 'testing', 'APP_URL': 'http://localhost', 'DB_CONNECTION': 'sqlite', 'DB_DATABASE': ':memory:', 'DB_URL': '', 'CACHE_STORE': 'array', 'SESSION_DRIVER': 'array'}
    run('php-tests', ['php', 'vendor/bin/phpunit'], ROOT, testenv)
    tests = sorted(str(p.relative_to(ROOT)) for p in (ROOT / 'tests').glob('*.test.mjs'))
    run('node-tests', ['node', '--test', *tests], ROOT, env)
    shutil.copytree(REPO / 'node_modules', ROOT / 'node_modules', dirs_exist_ok=True)
    run('build', ['npm', 'run', 'build'], ROOT, env)
    after = hashes()
    (OUT / 'source-post.json').write_text(json.dumps(after, indent=2))
    assert before == after, 'Source drift during closure'
    (OUT / 'profile.json').write_text(json.dumps({'root': str(ROOT), 'port': 8018, 'database': 'isolated SQLite; PHPUnit :memory:', 'operational_env_read': False, 'source_files': len(before), 'drift': 0}, indent=2))
